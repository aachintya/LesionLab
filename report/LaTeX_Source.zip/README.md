# MILK10k report: improved EfficientNetV2 ensemble

The LaTeX project is the editorial master. The five main chapters focus on the
three-modality frozen-feature/TTA ensemble, matched eleven-class validation
comparison, broader-screening evaluation, EDA, class error analysis and the
Streamlit interpretation interface. Existing main-chapter headings, result tables
and numerical evidence are preserved. Historical JI-ADF adaptation results remain
secondary context and are not presented as published-paper outperformance.

The supplementary direct binary experiment is confined to Appendix A. It reports
MILK10k + ISIC 2019 development, PAD-UFES-20 external testing, locked thresholds,
all five controls/candidates and the unresolved melanoma-sensitivity trade-off.
Its endpoint and cohorts are explicitly separated from the main ensemble results.
The appendix tables are generated from the verified Version 4 result JSON files.

The preceding PDF and LaTeX project are archived in
`output/archive/report_before_ensemble_focus_2026-10-30.zip`.
The saved baseline, trained models, app and archived study predictions remain
unchanged. This is a local editorial revision with no commits or new training.

## Compile the portable project

The main file is `main.tex`; bibliography entries are in `references.bib`.
Use `latexmk -pdf main.tex`, or Tectonic. No shell escape, original images,
Python environment, model weights or dataset access is needed to compile the
portable source ZIP. For Overleaf, upload the ZIP as a new project and select
`main.tex` with the standard pdfLaTeX compiler.

The delivered PDF was built with Tectonic 0.17.0 and checked with the native Codex
LaTeX compiler. If the default bundle relay is unavailable:

```sh
tectonic --bundle https://data1.fullyjustified.net/tlextras-2022.0r0.tar main.tex
```

## Rebuild in the local repository

The saved TeX project is the editorial master. The build script compiles it in
place and exports only its active dependencies. From the repository root:

```sh
PYTHONPATH=tmp/report_libs /Users/apple/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 reports/milk10k_late_fusion/build_current_report.py
```

To regenerate only the new descriptive analysis tables and vector figures from
the archived predictions, run `reports/milk10k_late_fusion/generate_report_25_analysis.py`
with the same Python environment. This performs no model fitting or inference.
The legacy Markdown converter and `update_screening_report.py` describe earlier
editions and must not overwrite this expanded TeX master.

Integrity records for this revision are in `output/report_ensemble_focus_2026-10-30/`.
